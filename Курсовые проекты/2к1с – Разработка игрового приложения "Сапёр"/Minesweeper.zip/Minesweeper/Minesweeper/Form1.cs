﻿using Minesweeper.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minesweeper
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MapController.Init(this);
            DifficultySelection f4 = new DifficultySelection();
            f4.ShowDialog();
            MapController.NewDifficult(this, f4.dif);
        }

        private void правилаИгрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rools f2 = new Rools();
            f2.ShowDialog();
        }

        private void оПриложенииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutApp f3 = new AboutApp();
            f3.ShowDialog();
        }

        private void начатьНовуюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MapController.NewGame(this);
        }

        private void сменитьСложностьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DifficultySelection f4 = new DifficultySelection();
            f4.ShowDialog();
            MapController.NewDifficult(this, f4.dif);
        }
    }
}
